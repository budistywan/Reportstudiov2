/**
 * app.js — Entry point Report Studio
 *
 * Urutan init:
 *  1. Store (state global)
 *  2. UI modules (welcome, sidebar, topbar, panel)
 *  3. Editor (canvas, blocks)
 *  4. Feature modules (fill, export)
 *  5. Load saved state / show welcome
 */

import { store } from './core/store.js';
import { initWelcome } from './ui/welcome.js';
import { initSidebar } from './ui/sidebar.js';
import { initTopbar } from './ui/topbar.js';
import { initPanel } from './ui/rightPanel.js';
import { initCanvas } from './editor/canvas.js';
import { initFill } from './fill/fillPanel.js';
import { initExport } from './export/exportModal.js';

async function boot() {
  // Init semua UI modules (render shell HTML ke placeholder)
  initWelcome();
  initSidebar();
  initTopbar();
  initPanel();
  initCanvas();
  initFill();
  initExport();

  // Load saved state dari localStorage
  store.load();
}

boot();
