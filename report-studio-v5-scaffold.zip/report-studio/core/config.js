/**
 * core/config.js — Konstanta & konfigurasi statis
 *
 * Ganti nilai di sini untuk mengubah defaults global.
 * Tidak ada logic di sini — murni data.
 */

export const ROMAN = ['0','I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];

export const TYPO_MAP = {
  classic: { h: "'Playfair Display', serif",    b: "'Source Serif 4', serif" },
  sans:    { h: "'DM Sans', sans-serif",         b: "'JetBrains Mono', monospace" },
  slab:    { h: "'Roboto Slab', serif",          b: "'Lato', sans-serif" },
  elegant: { h: "'Cormorant Garamond', serif",   b: "'DM Sans', sans-serif" },
};

export const HEADER_STYLES = ['strip', 'logobar', 'corner', 'minimal'];

// Preset ids (definisi lengkap di core/presets.js)
export const PRESET_IDS = ['executive', 'corporate-red', 'modern-clean', 'minimal', 'diagonal', 'split-right'];

export const OPENER_COLORS = [
  '#c0392b', '#1a3a6b', '#1e6b45',
  '#5e35b1', '#c9a84c', '#2c3e50',
];

export const FILL_HEIGHTS = {
  full:       1.00,
  'two-thirds': 0.67,
  half:       0.50,
  'one-third':  0.33,
};

// Front matter keywords untuk parser
export const FM_KEYWORDS = [
  'HALAMAN SAMPUL', 'HALAMAN PENGESAHAN', 'KATA PENGANTAR',
  'DAFTAR ISI', 'DAFTAR TABEL', 'DAFTAR GAMBAR', 'DAFTAR GRAFIK',
  'DAFTAR DIAGRAM', 'RINGKASAN EKSEKUTIF', 'EXECUTIVE SUMMARY',
  'LEMBAR PENGESAHAN', 'UCAPAN TERIMA KASIH', 'DAFTAR SINGKATAN',
];

// Export format yang didukung
export const EXPORT_FORMATS = {
  json: { label: 'JSON (Project)',  ext: '.json',  icon: '💾' },
  pdf:  { label: 'PDF',            ext: '.pdf',   icon: '📄' },
  docx: { label: 'Word (.docx)',   ext: '.docx',  icon: '📝' },
  icml: { label: 'ICML (InDesign)',ext: '.icml',  icon: '🖨' },
};
