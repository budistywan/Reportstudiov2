/**
 * core/presets.js — Definisi preset visual
 *
 * Setiap preset mendefinisikan tiga komponen sekaligus:
 *   cover  → layout halaman sampul
 *   header → layout header setiap halaman konten
 *   footer → layout footer setiap halaman konten
 *
 * Preset bersifat FIXED — user hanya bisa ganti:
 *   - Warna (accent, gold) via cfg
 *   - Logo via cfg.logo
 *   - Teks dinamis (title, company, year) via cfg
 *
 * Cara render: lihat ui/presets/coverRenderer.js, headerRenderer.js, footerRenderer.js
 * Cara pilih:  welcome screen (tab Preset) + right panel accordion "🎨 Preset Desain"
 *
 * Menambah preset baru:
 *   1. Tambah entry di PRESETS di bawah
 *   2. Tambah thumbnail SVG di ui/presets/thumbnails.js
 *   3. Implement renderer di coverRenderer/headerRenderer/footerRenderer
 *      dengan case untuk preset id baru
 */

/**
 * @typedef {Object} Preset
 * @property {string}   id          - identifier unik, dipakai di cfg.preset
 * @property {string}   name        - nama tampilan
 * @property {string}   description - deskripsi singkat
 * @property {string}   category    - 'formal' | 'modern' | 'minimal' | 'bold'
 * @property {string}   defaultAccent  - warna accent default preset ini
 * @property {string}   defaultGold    - warna gold default preset ini
 * @property {CoverDef}  cover
 * @property {HeaderDef} header
 * @property {FooterDef} footer
 */

/**
 * @typedef {Object} CoverDef
 * @property {string} layout
 *   'centered'      → logo + judul + perusahaan di tengah vertikal
 *   'split-left'    → panel warna kiri 40%, konten kanan
 *   'split-right'   → panel warna kanan 40%, konten kiri
 *   'full-color'    → background penuh warna, teks putih
 *   'top-band'      → band warna atas, konten di bawah
 *   'bottom-band'   → konten di atas, band warna bawah
 *   'diagonal'      → potongan diagonal warna
 * @property {boolean} showLogo
 * @property {boolean} showYear
 * @property {boolean} showDivider   - garis pembatas antara judul & perusahaan
 * @property {string}  logoPosition  - 'top-left' | 'top-center' | 'top-right' | 'bottom-left'
 */

/**
 * @typedef {Object} HeaderDef
 * @property {string} layout
 *   'strip'    → background solid accent, logo kiri, judul kanan
 *   'logobar'  → border bottom accent, logo kiri, judul kanan
 *   'corner'   → block warna kiri sebagai logo holder
 *   'minimal'  → teks saja + garis gradient tipis
 *   'none'     → tanpa header (hanya footer)
 * @property {boolean} showTitle    - tampilkan judul laporan
 * @property {boolean} showCompany  - tampilkan nama perusahaan
 * @property {boolean} showLogo
 */

/**
 * @typedef {Object} FooterDef
 * @property {string} layout
 *   'bar'      → garis gradient + nomor halaman kanan, perusahaan kiri
 *   'minimal'  → hanya nomor halaman, tipis
 *   'full'     → bar warna penuh (gold), teks putih
 *   'none'     → tanpa footer
 * @property {boolean} showPageNum
 * @property {boolean} showCompany
 * @property {boolean} showBabTitle - tampilkan judul bab aktif
 */

// ═══════════════════════════════════════════════════════════════════════════
// PRESET DEFINITIONS
// ═══════════════════════════════════════════════════════════════════════════

export const PRESETS = [

  // ── 1. EKSEKUTIF ─────────────────────────────────────────────────────────
  {
    id:           'executive',
    name:         'Eksekutif',
    description:  'Formal & berwibawa. Cocok untuk laporan tahunan, board report.',
    category:     'formal',
    defaultAccent: '#1a3a6b',
    defaultGold:   '#c9a84c',
    cover: {
      layout:       'split-left',
      showLogo:     true,
      showYear:     true,
      showDivider:  true,
      logoPosition: 'top-left',
    },
    header: {
      layout:      'strip',
      showTitle:   true,
      showCompany: true,
      showLogo:    true,
    },
    footer: {
      layout:      'bar',
      showPageNum: true,
      showCompany: true,
      showBabTitle: true,
    },
  },

  // ── 2. KORPORAT MERAH ────────────────────────────────────────────────────
  {
    id:           'corporate-red',
    name:         'Korporat',
    description:  'Bold & profesional. Cocok untuk proposal, company profile.',
    category:     'bold',
    defaultAccent: '#c0392b',
    defaultGold:   '#c9a84c',
    cover: {
      layout:       'full-color',
      showLogo:     true,
      showYear:     true,
      showDivider:  false,
      logoPosition: 'top-left',
    },
    header: {
      layout:      'corner',
      showTitle:   true,
      showCompany: false,
      showLogo:    true,
    },
    footer: {
      layout:      'full',
      showPageNum: true,
      showCompany: true,
      showBabTitle: false,
    },
  },

  // ── 3. MODERN CLEAN ──────────────────────────────────────────────────────
  {
    id:           'modern-clean',
    name:         'Modern',
    description:  'Bersih & kontemporer. Cocok untuk laporan teknis, CSR.',
    category:     'modern',
    defaultAccent: '#2c3e50',
    defaultGold:   '#3498db',
    cover: {
      layout:       'top-band',
      showLogo:     true,
      showYear:     true,
      showDivider:  true,
      logoPosition: 'top-right',
    },
    header: {
      layout:      'logobar',
      showTitle:   true,
      showCompany: true,
      showLogo:    true,
    },
    footer: {
      layout:      'bar',
      showPageNum: true,
      showCompany: false,
      showBabTitle: true,
    },
  },

  // ── 4. MINIMALIS ─────────────────────────────────────────────────────────
  {
    id:           'minimal',
    name:         'Minimalis',
    description:  'Tipografis & elegan. Cocok untuk whitepaper, research report.',
    category:     'minimal',
    defaultAccent: '#222222',
    defaultGold:   '#888888',
    cover: {
      layout:       'bottom-band',
      showLogo:     true,
      showYear:     true,
      showDivider:  false,
      logoPosition: 'bottom-left',
    },
    header: {
      layout:      'minimal',
      showTitle:   true,
      showCompany: false,
      showLogo:    false,
    },
    footer: {
      layout:      'minimal',
      showPageNum: true,
      showCompany: true,
      showBabTitle: false,
    },
  },

  // ── 5. DIAGONAL ──────────────────────────────────────────────────────────
  {
    id:           'diagonal',
    name:         'Diagonal',
    description:  'Dinamis & kreatif. Cocok untuk laporan marketing, inovasi.',
    category:     'bold',
    defaultAccent: '#1e6b45',
    defaultGold:   '#f1c40f',
    cover: {
      layout:       'diagonal',
      showLogo:     true,
      showYear:     false,
      showDivider:  false,
      logoPosition: 'top-right',
    },
    header: {
      layout:      'strip',
      showTitle:   true,
      showCompany: true,
      showLogo:    true,
    },
    footer: {
      layout:      'bar',
      showPageNum: true,
      showCompany: true,
      showBabTitle: false,
    },
  },

  // ── 6. SPLIT KANAN ───────────────────────────────────────────────────────
  {
    id:           'split-right',
    name:         'Split',
    description:  'Modern asimetris. Cocok untuk laporan sustainability, ESG.',
    category:     'modern',
    defaultAccent: '#5e35b1',
    defaultGold:   '#ab47bc',
    cover: {
      layout:       'split-right',
      showLogo:     true,
      showYear:     true,
      showDivider:  true,
      logoPosition: 'top-left',
    },
    header: {
      layout:      'logobar',
      showTitle:   true,
      showCompany: true,
      showLogo:    true,
    },
    footer: {
      layout:      'bar',
      showPageNum: true,
      showCompany: true,
      showBabTitle: true,
    },
  },

];

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Ambil preset by id, fallback ke preset pertama */
export function getPreset(id) {
  return PRESETS.find(p => p.id === id) || PRESETS[0];
}

/** Default preset id */
export const DEFAULT_PRESET_ID = 'executive';
