/**
 * core/store.js — State management terpusat
 *
 * Shape state:
 *  cfg        → konfigurasi proyek (nama, perusahaan, warna, tipografi, dll)
 *  skeleton   → struktur laporan [{id, num, name, subs:[{id,num,name}]}]
 *  pages      → konten per sub-bab { [subId]: { pages:[], openerColor, openerSub } }
 *  meta       → projectReady, currentSubId, dll
 *
 * Pattern: observer sederhana — modul subscribe ke perubahan state tertentu.
 * Tidak ada framework, tidak ada proxy magic — eksplisit dan mudah di-debug.
 */

// ── Default config ──────────────────────────────────────────────────────────
const DEFAULT_CFG = {
  title:      '',
  company:    '',
  year:       String(new Date().getFullYear()),
  accent:     '#c0392b',
  gold:       '#c9a84c',
  typo:       'classic',   // 'classic' | 'sans' | 'slab' | 'elegant'
  hdrStyle:   'strip',     // deprecated — sekarang dikontrol oleh preset
  preset:     'executive', // id preset (lihat core/presets.js)
  logo:       null,        // base64 string
  logoName:   '',
};

const LS_KEY = 'rs5_store';

// ── Internal state ───────────────────────────────────────────────────────────
let _state = {
  cfg:           { ...DEFAULT_CFG },
  skeleton:      [],   // [{id, num, name, subs:[{id,num,name}]}]
  pages:         {},   // { [subId]: { pages:[], openerColor, openerSub } }
  projectReady:  false,
  currentSubId:  null,
};

// ── Listeners ────────────────────────────────────────────────────────────────
// { eventName: [fn, fn, ...] }
const _listeners = {};

function on(event, fn) {
  if (!_listeners[event]) _listeners[event] = [];
  _listeners[event].push(fn);
}

function off(event, fn) {
  if (!_listeners[event]) return;
  _listeners[event] = _listeners[event].filter(f => f !== fn);
}

function emit(event, payload) {
  (_listeners[event] || []).forEach(fn => fn(payload));
}

// ── Getters ──────────────────────────────────────────────────────────────────
function getCfg()          { return { ..._state.cfg }; }
function getSkeleton()     { return _state.skeleton; }
function getPages(subId)   { return _state.pages[subId] || { pages: [], openerColor: _state.cfg.accent, openerSub: '' }; }
function getCurrentSubId() { return _state.currentSubId; }
function isReady()         { return _state.projectReady; }

/** Cari node (bab atau sub-bab) by id, return { node, parent? } */
function findNode(id) {
  for (const bab of _state.skeleton) {
    if (bab.id === id) return { node: bab, parent: null };
    for (const sub of (bab.subs || [])) {
      if (sub.id === id) return { node: sub, parent: bab };
    }
  }
  return null;
}

// ── Setters / Mutations ──────────────────────────────────────────────────────

function setCfg(partial) {
  _state.cfg = { ..._state.cfg, ...partial };
  emit('cfg:change', _state.cfg);
  _persist();
}

function setSkeleton(skeleton) {
  _state.skeleton = skeleton;
  // Pastikan semua sub-bab punya entry di pages
  _ensurePages();
  emit('skeleton:change', _state.skeleton);
  _persist();
}

function setCurrentSub(subId) {
  _state.currentSubId = subId;
  emit('nav:change', subId);
}

function setPages(subId, data) {
  _state.pages[subId] = data;
  emit('pages:change', { subId, data });
  _persist();
}

function setProjectReady(val) {
  _state.projectReady = val;
  emit('project:ready', val);
}

// ── Persistence ──────────────────────────────────────────────────────────────

function _persist() {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(_state));
  } catch(e) {
    console.warn('[store] localStorage gagal:', e);
  }
}

function load() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) {
      const saved = JSON.parse(raw);
      _state = {
        cfg:          { ...DEFAULT_CFG, ...(saved.cfg || {}) },
        skeleton:     saved.skeleton   || [],
        pages:        saved.pages      || {},
        projectReady: saved.projectReady || false,
        currentSubId: saved.currentSubId || null,
      };
    }
  } catch(e) {
    console.warn('[store] Gagal load state:', e);
  }

  if (_state.projectReady) {
    emit('project:ready', true);
  } else {
    emit('project:new', null);
  }
}

function exportJSON() {
  return JSON.stringify({ version: '5.0', ..._state, at: new Date().toISOString() }, null, 2);
}

function importJSON(jsonStr) {
  const d = JSON.parse(jsonStr);
  if (d.skeleton) _state.skeleton = d.skeleton;
  if (d.pages)    _state.pages    = d.pages;
  if (d.cfg)      _state.cfg      = { ...DEFAULT_CFG, ...d.cfg };
  _state.projectReady = true;
  _persist();
  emit('project:ready', true);
}

function resetAll() {
  try { localStorage.removeItem(LS_KEY); } catch(e) {}
  location.reload();
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function _ensurePages() {
  for (const bab of _state.skeleton) {
    for (const sub of (bab.subs || [])) {
      if (!_state.pages[sub.id]) {
        _state.pages[sub.id] = {
          pages:       [],
          openerColor: _state.cfg.accent,
          openerSub:   '',
        };
      }
    }
  }
}

/** Generate unique id sederhana */
function uid() {
  return Math.random().toString(36).slice(2, 9);
}

// ── Export public API ────────────────────────────────────────────────────────
export const store = {
  // Subscribe
  on, off,

  // Getters
  getCfg, getSkeleton, getPages, getCurrentSubId, isReady, findNode,

  // Mutations
  setCfg, setSkeleton, setCurrentSub, setPages, setProjectReady,

  // Persistence
  load, exportJSON, importJSON, resetAll,

  // Utils
  uid,
};
