/**
 * core/events.js — Global event bus
 *
 * Untuk komunikasi antar modul tanpa tight coupling.
 * Modul A emit event → Modul B yang subscribe bereaksi.
 *
 * Events yang dipakai di seluruh app:
 *
 *  Store events (dari store.js):
 *   'cfg:change'       → cfg baru
 *   'skeleton:change'  → skeleton baru
 *   'nav:change'       → subId yang aktif berubah
 *   'pages:change'     → { subId, data }
 *   'project:ready'    → project loaded / dibuat
 *   'project:new'      → belum ada project, tampilkan welcome
 *
 *  UI events (dari UI modules):
 *   'toast'            → string pesan
 *   'modal:confirm'    → { title, desc, keyword, onConfirm }
 *   'fill:ai:request'  → { subId, blockId, prompt }
 *   'fill:excel:data'  → { rows, mapping }
 *   'export:request'   → { format } — 'pdf'|'docx'|'icml'|'json'
 *
 * re-export store.on/off/emit agar modul tidak perlu import store langsung
 * hanya untuk event listening.
 */

export { store as bus } from './store.js';
