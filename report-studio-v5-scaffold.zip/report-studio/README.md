# Report Studio v5

Visual editor laporan profesional — dibangun sebagai multi-file ES Module project.

## Stack

- **Vanilla ES Modules** — tidak ada bundler, langsung jalan di browser modern
- **CSS per modul** — satu file CSS per area fungsional
- **GitHub Pages ready** — buka `index.html` langsung, atau serve via `npx serve .`

---

## Struktur Folder

```
report-studio/
├── index.html              ← shell HTML, mount point semua UI
├── app.js                  ← entry point, init semua modul
│
├── core/
│   ├── store.js            ← state management (skeleton, pages, cfg)
│   ├── config.js           ← konstanta global
│   └── events.js           ← re-export event bus
│
├── ui/
│   ├── welcome.js          ← welcome screen + skeleton builder
│   ├── sidebar.js          ← tree navigasi + progress
│   ├── topbar.js           ← toolbar actions
│   ├── rightPanel.js       ← panel editor (layout, visual, typo, dll)
│   └── toast.js            ← toast + confirm modal
│
├── editor/
│   ├── canvas.js           ← A4 page renderer + save loop
│   ├── blocks.js           ← semua block types (text, image, stat, dll)
│   ├── opener.js           ← opener bab logic
│   └── pageManager.js      ← add/delete/reorder pages
│
├── fill/
│   ├── ai.js               ← Anthropic API integration
│   ├── excel.js            ← SheetJS parser
│   └── fillPanel.js        ← UI panel fill (AI + Excel)
│
├── export/
│   ├── exportModal.js      ← modal pilih format
│   ├── pdf.js              ← export PDF
│   ├── docx.js             ← export Word
│   └── icml.js             ← export ICML (InDesign)
│
├── styles/
│   ├── variables.css       ← CSS custom properties (design tokens)
│   ├── shell.css           ← dark UI shell (sidebar, topbar)
│   ├── components.css      ← modal, toast, buttons
│   ├── welcome.css         ← welcome screen
│   ├── panel.css           ← right panel
│   ├── document.css        ← A4, blocks, opener
│   ├── fill.css            ← fill panel
│   └── export.css          ← export modal
│
└── assets/
    └── fonts.css           ← Google Fonts imports
```

---

## State Shape

```js
{
  cfg: {
    title, company, year,
    accent, gold,
    typo,      // 'classic' | 'sans' | 'slab' | 'elegant'
    hdrStyle,  // 'strip' | 'logobar' | 'corner' | 'minimal'
    logo,      // base64 string
  },
  skeleton: [
    {
      id, num, name,
      subs: [{ id, num, name }]
    }
  ],
  pages: {
    [subId]: {
      pages: [{ id, blocks: [blockDef] }],
      openerColor: '#c0392b',
      openerSub: 'deskripsi singkat'
    }
  },
  projectReady: true,
  currentSubId: 'abc123'
}
```

---

## Block Interface

Setiap block type mengikuti kontrak ini:

```js
// Render
renderBlock(def) → HTMLElement

// Serialize (DOM → data)
serializeBlock(el) → blockDef

// Fill
fillBlockFromText(el, text)     // untuk AI fill
fillBlockFromData(el, rowData)  // untuk Excel fill
```

---

## Events (store.on / store.off)

| Event | Payload | Siapa emit |
|-------|---------|-----------|
| `cfg:change` | cfg object | store.setCfg() |
| `skeleton:change` | skeleton[] | store.setSkeleton() |
| `nav:change` | subId | store.setCurrentSub() |
| `pages:change` | { subId, data } | store.setPages() |
| `project:ready` | true | store.setProjectReady() |
| `project:new` | null | store.load() |

---

## Cara Kerja Bersama Claude

Saat mengerjakan fitur tertentu, share file yang relevan saja:

- **Ubah block baru** → share `editor/blocks.js`
- **Fix parsing skeleton** → share `ui/welcome.js`
- **Implementasi PDF export** → share `export/pdf.js` + `export/exportModal.js`
- **AI fill** → share `fill/ai.js` + `fill/fillPanel.js`

State dan kontrak antar modul ada di `core/store.js` dan README ini.

---

## Roadmap

- [x] Scaffold & arsitektur
- [ ] Migrasi UI dari v4 (welcome, sidebar, topbar, panel)
- [ ] Migrasi editor dari v4 (canvas, blocks, opener)
- [ ] Export PDF
- [ ] AI Fill (per-block + per-sub-bab)
- [ ] Excel Import + mapping
- [ ] Export DOCX
- [ ] Export ICML
