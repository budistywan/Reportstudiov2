/**
 * fill/ai.js — AI content fill via Anthropic API
 *
 * Mode 1: Per-block
 *   requestAIFill(blockEl, prompt) → generate konten untuk 1 block
 *
 * Mode 2: Per-sub-bab
 *   requestAIFillSub(subId, outline) → generate semua block dalam sub-bab
 *
 * Konteks yang dikirim ke AI:
 *  - Nama laporan, perusahaan, tahun
 *  - Nomor & judul bab + sub-bab
 *  - Block type yang akan diisi
 *  - Prompt / outline dari user
 *
 * API: Anthropic /v1/messages (claude-sonnet-4-20250514)
 * Tidak ada API key di frontend → harus via proxy atau user input key sendiri
 *
 * TODO: tentukan apakah API key diinput user atau via backend proxy
 */

import { store } from '../core/store.js';
import { fillBlockFromText } from '../editor/blocks.js';
import { showToast } from '../ui/toast.js';

/**
 * Fill satu block dengan AI
 * @param {HTMLElement} blockEl
 * @param {string} prompt - instruksi user
 * @param {string} [apiKey] - opsional, jika user input langsung
 */
export async function requestAIFill(blockEl, prompt, apiKey) {
  const cfg       = store.getCfg();
  const subId     = store.getCurrentSubId();
  const found     = store.findNode(subId);
  const blockType = blockEl.dataset.blockType;

  const systemPrompt = `Kamu adalah asisten penulisan laporan profesional.
Isi konten untuk bagian laporan berikut dalam Bahasa Indonesia yang formal dan padat.
Laporan: ${cfg.title} | Perusahaan: ${cfg.company} | Tahun: ${cfg.year}
Bab: ${found?.parent?.name || ''} | Sub-bab: ${found?.node?.name || ''}
Block type: ${blockType}
Kembalikan HANYA konten teks/HTML yang diminta, tanpa penjelasan tambahan.`;

  showToast('⏳ Generating...');

  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // 'x-api-key': apiKey,   // aktifkan jika user input key
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    const data = await res.json();
    const text = data.content?.find(c => c.type === 'text')?.text || '';

    fillBlockFromText(blockEl, text);
    showToast('✨ Konten berhasil di-generate');
  } catch(err) {
    showToast('⚠ Gagal generate: ' + err.message);
    console.error('[ai] Error:', err);
  }
}

/**
 * Fill seluruh sub-bab berdasarkan outline
 * @param {string} subId
 * @param {string} outline
 */
export async function requestAIFillSub(subId, outline) {
  // TODO: iterasi semua block dalam sub-bab, generate per block
}
