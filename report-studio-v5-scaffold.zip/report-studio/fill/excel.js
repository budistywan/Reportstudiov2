/**
 * fill/excel.js — Excel import & mapping ke blocks
 *
 * Flow:
 *  1. User upload .xlsx
 *  2. Parse dengan SheetJS → { headers:[], rows:[[]] }
 *  3. Tampilkan mapping UI (kolom → block target)
 *  4. User konfirmasi → inject data ke blocks
 *
 * Cocok untuk: stat blocks, tabel, data series diagram
 *
 * Library: SheetJS (via CDN)
 *   <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js">
 *   → window.XLSX tersedia global
 */

import { fillBlockFromData } from '../editor/blocks.js';
import { showToast } from '../ui/toast.js';

/**
 * Parse file Excel → { headers, rows }
 * @param {File} file
 * @returns {Promise<{ headers:string[], rows:any[][] }>}
 */
export async function parseExcel(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const wb = XLSX.read(e.target.result, { type: 'binary' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const raw = XLSX.utils.sheet_to_json(ws, { header: 1 });

        const headers = raw[0] || [];
        const rows    = raw.slice(1);
        resolve({ headers, rows });
      } catch(err) {
        reject(err);
      }
    };
    reader.readAsBinaryString(file);
  });
}

/**
 * Inject data Excel ke block berdasarkan mapping
 * @param {HTMLElement} blockEl
 * @param {Object} mapping   - { colIndex → fieldName }
 * @param {any[][]} rows
 */
export function applyExcelMapping(blockEl, mapping, rows) {
  // TODO: transform rows + mapping → fillBlockFromData(blockEl, rowData)
  showToast('✓ Data Excel diterapkan');
}
