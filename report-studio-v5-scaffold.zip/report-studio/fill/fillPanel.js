/**
 * fill/fillPanel.js — UI panel untuk semua fill operations
 *
 * Menampilkan modal/drawer dengan dua tab:
 *
 *  Tab 1: ✨ AI Fill
 *   - Scope: block aktif / seluruh sub-bab
 *   - Textarea untuk prompt/outline
 *   - Tombol generate
 *   - (Opsional) input API key jika tidak ada backend
 *
 *  Tab 2: 📊 Excel Fill
 *   - Upload .xlsx
 *   - Preview tabel (header + 5 baris pertama)
 *   - Mapping UI: drag/select kolom → field block
 *   - Tombol terapkan
 *
 * CSS: styles/fill.css
 */

import { requestAIFill, requestAIFillSub } from './ai.js';
import { parseExcel, applyExcelMapping } from './excel.js';
import { store } from '../core/store.js';
import { showToast } from '../ui/toast.js';

export function initFill() {
  // TODO: inject fill panel HTML ke DOM (tersembunyi, dibuka via tombol)
  // Bind open/close events
}

export function openFillPanel(targetBlockEl = null) {
  // TODO: tampilkan panel, set context (block atau sub-bab)
}

function _handleAISubmit(prompt, scope, blockEl) {
  if (scope === 'block' && blockEl) {
    requestAIFill(blockEl, prompt);
  } else {
    const subId = store.getCurrentSubId();
    requestAIFillSub(subId, prompt);
  }
}

async function _handleExcelUpload(file) {
  try {
    const { headers, rows } = await parseExcel(file);
    // TODO: render mapping UI
  } catch(err) {
    showToast('⚠ Gagal baca Excel: ' + err.message);
  }
}
