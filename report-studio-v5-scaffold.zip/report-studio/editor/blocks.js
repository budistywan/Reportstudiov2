/**
 * editor/blocks.js — Block system (semua tipe konten)
 *
 * Setiap block punya interface standar:
 *
 *   renderBlock(blockDef) → HTMLElement
 *   serializeBlock(el)    → blockDef object
 *
 * Block types:
 *  text     → { type:'text', variant:'full'|'two-thirds'|'half'|'one-third', html:'' }
 *  image    → { type:'image', variant:'full'|'two-thirds'|'half'|'one-third', src:'', caption:'' }
 *  collage  → { type:'collage', cols:2, rows:1, images:[] }
 *  stat     → { type:'stat', cols:2, rows:1, items:[{value,label,icon}] }
 *  quote    → { type:'quote', variant:'classic'|'pull'|'minimal', text:'', source:'' }
 *  diagram  → { type:'diagram', variant:'chart'|'infog'|'timeline-h'|'timeline-v', data:{} }
 *
 * Fill interface (untuk AI & Excel fill):
 *  fillBlockFromText(el, text)     → inject teks ke block
 *  fillBlockFromData(el, rowData)  → inject data terstruktur (Excel row)
 *
 * CSS: styles/document.css
 */

import { store } from '../core/store.js';
import { saveCanvas } from './canvas.js';

// ── Public: render ────────────────────────────────────────────────────────────
export function renderBlock(def) {
  switch (def.type) {
    case 'text':    return _renderText(def);
    case 'image':   return _renderImage(def);
    case 'collage': return _renderCollage(def);
    case 'stat':    return _renderStat(def);
    case 'quote':   return _renderQuote(def);
    case 'diagram': return _renderDiagram(def);
    default:
      console.warn('[blocks] Unknown block type:', def.type);
      return document.createElement('div');
  }
}

// ── Public: serialize ─────────────────────────────────────────────────────────
export function serializeBlock(el) {
  const type = el.dataset.blockType;
  // TODO: baca data dari DOM → return blockDef
  return { type };
}

// ── Public: fill ──────────────────────────────────────────────────────────────
export function fillBlockFromText(el, text) {
  // TODO: inject text ke contenteditable yang relevan
}

export function fillBlockFromData(el, rowData) {
  // TODO: inject structured data (untuk stat, table)
}

// ── Private renderers ─────────────────────────────────────────────────────────

function _renderText(def) {
  // TODO: div.cb.cb-text dengan contenteditable
  const el = document.createElement('div');
  el.className = `cb cb-text cb-${def.variant}`;
  el.dataset.blockType = 'text';
  el.dataset.variant = def.variant;
  el.innerHTML = `
    <div class="cb-ctrl">
      <span class="cb-type-lbl">Teks · ${def.variant}</span>
      <button class="cb-ai-btn" title="Fill dengan AI">✨</button>
      <button class="cb-del-btn" title="Hapus block">×</button>
    </div>
    <div class="cb-content" contenteditable="true">${def.html || ''}</div>
  `;
  _attachBlockEvents(el);
  return el;
}

function _renderImage(def) {
  // TODO
  const el = document.createElement('div');
  el.className = `cb cb-image cb-${def.variant}`;
  el.dataset.blockType = 'image';
  return el;
}

function _renderCollage(def) {
  // TODO
  const el = document.createElement('div');
  el.className = 'cb cb-collage';
  el.dataset.blockType = 'collage';
  return el;
}

function _renderStat(def) {
  // TODO
  const el = document.createElement('div');
  el.className = 'cb cb-stat';
  el.dataset.blockType = 'stat';
  return el;
}

function _renderQuote(def) {
  // TODO
  const el = document.createElement('div');
  el.className = `cb cb-quote cb-quote-${def.variant}`;
  el.dataset.blockType = 'quote';
  return el;
}

function _renderDiagram(def) {
  // TODO
  const el = document.createElement('div');
  el.className = `cb cb-diagram cb-diagram-${def.variant}`;
  el.dataset.blockType = 'diagram';
  return el;
}

// ── Block events (delete, AI fill button, content change) ─────────────────────
function _attachBlockEvents(el) {
  el.querySelector('.cb-del-btn')?.addEventListener('click', () => {
    el.remove();
    saveCanvas();
  });

  el.querySelector('.cb-ai-btn')?.addEventListener('click', () => {
    // TODO: buka AI fill prompt untuk block ini
    // import { requestAIFill } from '../fill/ai.js';
  });

  el.querySelector('[contenteditable]')?.addEventListener('input', () => {
    saveCanvas();
  });
}
