/**
 * editor/canvas.js — A4 canvas renderer
 *
 * Tanggung jawab:
 *  - Listen ke nav:change → load pages sub-bab aktif
 *  - Render pages ke #pages-wrap
 *  - Setiap page = .pg-wrap > .a4 dengan header, body (drop-zone), footer
 *  - Drag-drop reorder blocks (dalam satu page)
 *  - Kalkulasi fill height (0–100%) per page → update badge
 *  - Save otomatis ke store.setPages() setiap kali konten berubah
 *
 * Berkolaborasi dengan:
 *  editor/blocks.js   → render tiap block type
 *  editor/opener.js   → render opener bab (page pertama)
 *  editor/pageManager.js → add/delete/reorder pages
 *
 * CSS: styles/document.css
 */

import { store } from '../core/store.js';
import { renderBlock } from './blocks.js';
import { renderOpener } from './opener.js';

export function initCanvas() {
  store.on('nav:change', _loadSub);
  store.on('project:ready', _show);

  document.getElementById('add-pg-btn')?.addEventListener('click', () => {
    // TODO: import addPage dari pageManager.js
  });
}

function _loadSub(subId) {
  if (!subId) return;
  const data = store.getPages(subId);
  _renderPages(subId, data);
}

function _renderPages(subId, data) {
  const wrap = document.getElementById('pages-wrap');
  wrap.innerHTML = '';

  // Page 0 selalu = opener bab
  wrap.appendChild(renderOpener(subId, data));

  // Pages konten
  (data.pages || []).forEach((pg, i) => {
    wrap.appendChild(_renderPage(subId, pg, i));
  });

  document.getElementById('add-pg-btn').style.display = 'flex';
}

function _renderPage(subId, pg, index) {
  // TODO: buat .pg-wrap dengan header, drop-zone, footer
  // Panggil renderBlock() untuk setiap block dalam pg.blocks[]
  const wrap = document.createElement('div');
  wrap.className = 'pg-wrap';
  // ...
  return wrap;
}

function _show() {
  document.getElementById('main').style.display = 'flex';
}

/** Dipanggil setiap kali ada perubahan di canvas → persist ke store */
function _save() {
  const subId = store.getCurrentSubId();
  if (!subId) return;
  const data = _serializeCurrentPages();
  store.setPages(subId, data);
}

function _serializeCurrentPages() {
  // TODO: baca DOM → return { pages:[], openerColor, openerSub }
  return { pages: [], openerColor: '', openerSub: '' };
}

export { _save as saveCanvas };
