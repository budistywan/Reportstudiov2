/**
 * editor/pageManager.js — Kelola halaman (add, delete, reorder)
 *
 * Satu sub-bab = opener page + N content pages.
 * Halaman konten disimpan di store.pages[subId].pages[]
 *
 * Setiap page object:
 *  { id, blocks: [blockDef, ...] }
 */

import { store } from '../core/store.js';
import { saveCanvas } from './canvas.js';
import { showConfirm } from '../ui/toast.js';

export function addPage(isFirst = false) {
  const subId = store.getCurrentSubId();
  if (!subId) return;

  const data = store.getPages(subId);
  const newPage = { id: store.uid(), blocks: [] };

  store.setPages(subId, {
    ...data,
    pages: [...(data.pages || []), newPage],
  });

  // TODO: re-render pages
}

export function deletePage(subId, pageId) {
  const data = store.getPages(subId);
  if ((data.pages || []).length <= 1) {
    // TODO: showToast('Minimal 1 halaman');
    return;
  }

  showConfirm({
    icon: '🗑',
    title: 'Hapus Halaman?',
    desc: 'Konten halaman ini akan dihapus permanen.',
    keyword: 'HAPUS',
    btnLabel: 'Hapus Halaman',
    onConfirm: () => {
      store.setPages(subId, {
        ...data,
        pages: data.pages.filter(p => p.id !== pageId),
      });
      // TODO: re-render
    },
  });
}
