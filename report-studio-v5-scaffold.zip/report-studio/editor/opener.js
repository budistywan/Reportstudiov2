/**
 * editor/opener.js — Opener bab (page pertama tiap sub-bab)
 *
 * Opener adalah halaman full-bleed berwarna dengan:
 *  - Background warna (bisa custom per bab)
 *  - Nomor & judul bab (dari skeleton)
 *  - Sub-judul editable
 *  - Optional: background image
 *
 * CSS: styles/document.css (.opener-*)
 */

import { store } from '../core/store.js';
import { saveCanvas } from './canvas.js';

/**
 * @param {string} subId
 * @param {{ openerColor:string, openerSub:string, pages:[] }} data
 * @returns {HTMLElement} .pg-wrap
 */
export function renderOpener(subId, data) {
  const found = store.findNode(subId);
  const node  = found?.node;
  const bab   = found?.parent;

  const color = data.openerColor || store.getCfg().accent;
  const sub   = data.openerSub || '';

  const wrap = document.createElement('div');
  wrap.className = 'pg-wrap opener-pg-wrap';
  wrap.dataset.subId = subId;

  wrap.innerHTML = `
    <div class="pg-lbl">
      <span class="pg-lbl-badge">Opener Bab</span>
    </div>
    <div class="a4 opener-pg" data-opener="1" style="min-height:840px">
      <div class="opener-body">
        <div class="opener-bg" style="background:${color}"></div>
        <div class="opener-overlay"></div>
        <div class="opener-deco"></div>
        <div class="opener-deco2"></div>
        <div class="opener-content">
          <div class="opener-num">${bab ? 'BAB ' + bab.num : ''}</div>
          <div class="opener-title">${node?.name || ''}</div>
          <div class="opener-sub"
               contenteditable="true"
               data-opener-sub="1">${sub}</div>
        </div>
      </div>
    </div>
  `;

  // Sub editable → auto save
  wrap.querySelector('[data-opener-sub]')?.addEventListener('input', () => saveCanvas());

  return wrap;
}

/** Set warna opener sub-bab aktif */
export function setOpenerColor(color) {
  const subId = store.getCurrentSubId();
  if (!subId) return;

  // Update DOM
  const bg = document.querySelector('.opener-pg .opener-bg');
  if (bg) bg.style.background = color;

  // Persist
  const data = store.getPages(subId);
  store.setPages(subId, { ...data, openerColor: color });
}
