/**
 * export/exportModal.js — Modal pilih format export
 *
 * Format:
 *  💾 JSON  → export project file (sudah ada di topbar)
 *  📄 PDF   → export/pdf.js
 *  📝 DOCX  → export/docx.js
 *  🖨 ICML  → export/icml.js
 *
 * Modal menampilkan:
 *  - Pilihan format (card dengan icon)
 *  - Opsi per format (misal: PDF → semua bab atau bab aktif saja)
 *  - Progress indicator saat proses export
 *
 * CSS: styles/export.css
 */

import { exportPDF }  from './pdf.js';
import { exportDOCX } from './docx.js';
import { exportICML } from './icml.js';
import { store }      from '../core/store.js';
import { showToast }  from '../ui/toast.js';
import { EXPORT_FORMATS } from '../core/config.js';

export function initExport() {
  // TODO: inject export modal HTML ke DOM
}

export function openExportModal() {
  // TODO: tampilkan modal dengan pilihan format
}

async function _doExport(format, options = {}) {
  showToast('⏳ Mengekspor...');
  try {
    switch (format) {
      case 'pdf':  await exportPDF(options);  break;
      case 'docx': await exportDOCX(options); break;
      case 'icml': await exportICML(options); break;
      case 'json': _exportJSON();             break;
    }
    showToast(`✓ Export ${format.toUpperCase()} selesai`);
  } catch(err) {
    showToast('⚠ Export gagal: ' + err.message);
    console.error('[export]', err);
  }
}

function _exportJSON() {
  const json = store.exportJSON();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
  a.download = `report-studio-${Date.now()}.json`;
  a.click();
}
