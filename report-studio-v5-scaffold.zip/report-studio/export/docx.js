/**
 * export/docx.js — Export ke Word (.docx)
 *
 * Library: docx.js (pure JS, no backend needed)
 *   https://docx.js.org/
 *   CDN: https://unpkg.com/docx@8/build/index.js
 *
 * Mapping block → DOCX element:
 *  text block   → Paragraph dengan heading/body style
 *  image block  → ImageRun
 *  stat block   → Table
 *  quote block  → Paragraph dengan border left
 *  diagram      → Screenshot via html2canvas → ImageRun
 *
 * Struktur dokumen:
 *  Styles (font, warna sesuai cfg)
 *  Sections per bab
 *   → Heading 1: judul bab
 *   → Heading 2: judul sub-bab
 *   → Content blocks
 *
 * @param {Object} options
 * @param {string} options.scope - 'all' | 'current'
 */
export async function exportDOCX(options = {}) {
  // TODO: implement dengan docx.js
  throw new Error('exportDOCX: belum diimplementasi');
}
