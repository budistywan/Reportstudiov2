/**
 * export/pdf.js — Export ke PDF
 *
 * Strategi (dua opsi, pilih satu):
 *
 * Opsi A — Pure frontend (html2canvas + jsPDF):
 *   + Tidak perlu backend
 *   - Kualitas font/layout terbatas, lambat untuk banyak halaman
 *   Library: https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js
 *            https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js
 *
 * Opsi B — Backend (Puppeteer/Playwright):
 *   + Kualitas pixel-perfect, persis seperti di browser
 *   - Perlu Node.js server
 *   → Kirim HTML/JSON ke endpoint, terima PDF balik
 *
 * TODO: tentukan opsi sebelum implementasi
 *
 * @param {Object} options
 * @param {string} options.scope - 'all' | 'current'
 * @param {boolean} options.withOpener - include opener pages
 */
export async function exportPDF(options = {}) {
  // TODO: implement
  throw new Error('exportPDF: belum diimplementasi');
}
