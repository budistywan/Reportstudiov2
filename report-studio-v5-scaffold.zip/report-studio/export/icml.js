/**
 * export/icml.js — Export ke ICML (InDesign Markup Language)
 *
 * ICML = XML format yang bisa di-place langsung di Adobe InDesign.
 * Satu file ICML = satu story (text frame content).
 *
 * Struktur ICML:
 *  <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
 *  <?aid style="50" type="snippet" readerVersion="6.0" featureSet="257" product="..." ?>
 *  <Document xmlns="http://ns.adobe.com/AdobeInDesign/idml/1.0/packaging" ...>
 *    <Story Self="u1b2" ...>
 *      <StoryPreference ... />
 *      <ParagraphStyleRange AppliedParagraphStyle="...">
 *        <CharacterStyleRange AppliedCharacterStyle="...">
 *          <Content>teks konten</Content>
 *        </CharacterStyleRange>
 *      </ParagraphStyleRange>
 *    </Story>
 *  </Document>
 *
 * Mapping block → ICML:
 *  text  → ParagraphStyleRange (Body Text / Heading)
 *  stat  → Table → XMLElement
 *  quote → ParagraphStyleRange (Pull Quote style)
 *  image → link placeholder (image harus di-relink di InDesign)
 *
 * Output: satu .icml file per sub-bab, atau satu file per laporan
 *
 * Referensi: https://wwwimages.adobe.com/content/dam/acom/en/devnet/indesign/sdk/cs6/idml/idml-specification.pdf
 *
 * @param {Object} options
 * @param {string} options.scope - 'all' | 'current'
 */
export async function exportICML(options = {}) {
  // TODO: implement ICML serializer
  throw new Error('exportICML: belum diimplementasi');
}

/**
 * Helper: escape XML special chars
 */
function _xmlEscape(str = '') {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Helper: generate ICML paragraph
 */
function _icmlParagraph(text, style = 'Body Text') {
  return `
    <ParagraphStyleRange AppliedParagraphStyle="ParagraphStyle/${_xmlEscape(style)}">
      <CharacterStyleRange AppliedCharacterStyle="CharacterStyle/$ID/[No character style]">
        <Content>${_xmlEscape(text)}</Content>
      </CharacterStyleRange>
    </ParagraphStyleRange>`;
}
