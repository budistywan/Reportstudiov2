/**
 * ui/presets/footerRenderer.js — Render footer halaman konten
 *
 * Entry point:
 *   renderFooter(cfg, context) → HTMLElement (.a4-ftr)
 *
 * context:
 *   context.babTitle  → judul sub-bab aktif
 *   context.pageNum   → nomor halaman (global, dihitung saat render)
 *   context.totalPages → total halaman (opsional)
 *
 * Layout:
 *   'bar'     → garis gradient gold-accent + info kiri & nomor kanan
 *   'minimal' → hanya nomor halaman, sangat tipis
 *   'full'    → bar solid gold, teks putih
 *   'none'    → return null
 *
 * CSS: styles/presets.css (.ftr-*)
 */

import { getPreset } from '../../core/presets.js';

/**
 * @param {Object} cfg
 * @param {{ babTitle:string, pageNum:number, totalPages?:number }} context
 * @returns {HTMLElement|null}
 */
export function renderFooter(cfg, context = {}) {
  const preset = getPreset(cfg.preset);
  const def    = preset.footer;

  if (def.layout === 'none') return null;

  const el = document.createElement('div');
  el.className = `a4-ftr ftr-${def.layout}`;
  el.style.cssText = 'position:absolute;bottom:0;left:0;right:0;';

  switch (def.layout) {
    case 'bar':     _bar(el, cfg, def, context);     break;
    case 'minimal': _minimal(el, cfg, def, context); break;
    case 'full':    _full(el, cfg, def, context);    break;
  }

  return el;
}

// ── Layout renderers ──────────────────────────────────────────────────────────

function _bar(el, cfg, def, ctx) {
  el.innerHTML = `
    <div style="height:3px;background:linear-gradient(90deg,${cfg.gold},${cfg.accent})"></div>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:5px 48px;background:#f9f9f9;border-top:1px solid #eee;">
      <div style="display:flex;align-items:center;gap:12px;">
        ${def.showCompany  ? `<span style="font-size:.56rem;color:#aaa;font-family:var(--doc-m)">${cfg.company}</span>` : ''}
        ${def.showCompany && def.showBabTitle ? `<span style="font-size:.5rem;color:#ccc">·</span>` : ''}
        ${def.showBabTitle && ctx.babTitle ? `<span style="font-size:.56rem;color:#aaa;font-family:var(--doc-m)">${ctx.babTitle}</span>` : ''}
      </div>
      ${def.showPageNum ? `<span style="font-size:.56rem;color:${cfg.accent};font-family:'JetBrains Mono',monospace;font-weight:500">${_pageStr(ctx)}</span>` : ''}
    </div>
  `;
}

function _minimal(el, cfg, def, ctx) {
  el.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:6px 48px;border-top:1px solid #f0f0f0;">
      ${def.showCompany ? `<span style="font-size:.52rem;color:#ccc;font-family:'JetBrains Mono',monospace">${cfg.company}</span>` : '<span></span>'}
      ${def.showPageNum ? `<span style="font-size:.52rem;color:#bbb;font-family:'JetBrains Mono',monospace">${_pageStr(ctx)}</span>` : ''}
    </div>
  `;
}

function _full(el, cfg, def, ctx) {
  el.innerHTML = `
    <div style="background:${cfg.gold};display:flex;align-items:center;justify-content:space-between;padding:7px 48px;">
      <div style="display:flex;align-items:center;gap:12px;">
        ${def.showCompany  ? `<span style="font-size:.58rem;color:rgba(255,255,255,.9);font-family:var(--doc-m);font-weight:500">${cfg.company}</span>` : ''}
        ${def.showBabTitle && ctx.babTitle ? `<span style="font-size:.52rem;color:rgba(255,255,255,.6);font-family:var(--doc-m)">${ctx.babTitle}</span>` : ''}
      </div>
      ${def.showPageNum ? `<span style="font-size:.58rem;color:rgba(255,255,255,.85);font-family:'JetBrains Mono',monospace;font-weight:600">${_pageStr(ctx)}</span>` : ''}
    </div>
  `;
}

// ── Helper ────────────────────────────────────────────────────────────────────
function _pageStr(ctx) {
  if (ctx.totalPages) return `${ctx.pageNum} / ${ctx.totalPages}`;
  return String(ctx.pageNum || 1);
}
