/**
 * ui/presets/thumbnails.js — SVG thumbnail untuk preset gallery picker
 *
 * Setiap thumbnail adalah SVG kecil (80×113px, rasio A4)
 * yang merepresentasikan layout preset secara visual.
 *
 * Dipakai oleh:
 *   - Welcome screen tab "Preset"
 *   - Right panel accordion "🎨 Preset Desain"
 *
 * Thumbnail menunjukkan tiga zona:
 *   - Cover (layout keseluruhan)
 *   - Header (strip kecil di atas)
 *   - Footer (strip kecil di bawah)
 */

/**
 * Render SVG thumbnail untuk preset tertentu
 * @param {import('../../core/presets.js').Preset} preset
 * @param {string} accent - hex warna accent
 * @param {string} gold   - hex warna gold
 * @returns {string} SVG string
 */
export function presetThumbnail(preset, accent = '#c0392b', gold = '#c9a84c') {
  const W = 80, H = 113;

  switch (preset.id) {
    case 'executive':    return _thumbSplitLeft(W, H, accent, gold);
    case 'corporate-red':return _thumbFullColor(W, H, accent, gold);
    case 'modern-clean': return _thumbTopBand(W, H, accent, gold);
    case 'minimal':      return _thumbBottomBand(W, H, accent, gold);
    case 'diagonal':     return _thumbDiagonal(W, H, accent, gold);
    case 'split-right':  return _thumbSplitRight(W, H, accent, gold);
    default:             return _thumbSplitLeft(W, H, accent, gold);
  }
}

// ── Thumbnail renderers ───────────────────────────────────────────────────────

function _thumbSplitLeft(W, H, ac, go) {
  const panelW = Math.round(W * 0.38);
  return _svg(W, H, `
    <!-- Panel kiri -->
    <rect x="0" y="0" width="${panelW}" height="${H}" fill="${ac}"/>
    <!-- Dekorasi -->
    <circle cx="${panelW - 8}" cy="16" r="14" fill="rgba(255,255,255,.06)"/>
    <!-- Garis gold kiri bawah -->
    <rect x="8" y="${H - 20}" width="20" height="1.5" fill="${go}"/>
    <!-- Konten kanan -->
    <rect x="${panelW + 12}" y="30" width="${W - panelW - 20}" height="2" fill="#ddd"/>
    <rect x="${panelW + 12}" y="36" width="${W - panelW - 28}" height="8" fill="#222" rx="1"/>
    <rect x="${panelW + 12}" y="47" width="${W - panelW - 24}" height="6" fill="#333" rx="1"/>
    <rect x="${panelW + 12}" y="56" width="${W - panelW - 32}" height="1" fill="#eee"/>
    <rect x="${panelW + 12}" y="62" width="${W - panelW - 36}" height="1.5" fill="#bbb"/>
    ${_hdrStrip(W, H, ac, go)}
    ${_ftrBar(W, H, ac, go)}
  `);
}

function _thumbFullColor(W, H, ac, go) {
  return _svg(W, H, `
    <rect x="0" y="0" width="${W}" height="${H}" fill="${ac}"/>
    <circle cx="${W + 10}" cy="-10" r="40" fill="rgba(255,255,255,.05)"/>
    <!-- Garis gold -->
    <rect x="12" y="${H - 32}" width="24" height="2" fill="${go}"/>
    <!-- Judul -->
    <rect x="12" y="${H - 27}" width="${W - 28}" height="7" fill="rgba(255,255,255,.85)" rx="1"/>
    <rect x="12" y="${H - 17}" width="${W - 40}" height="4" fill="rgba(255,255,255,.6)" rx="1"/>
    <!-- Logo pojok kiri atas -->
    <rect x="12" y="18" width="20" height="5" fill="rgba(255,255,255,.6)" rx="1"/>
    ${_hdrStrip(W, H, ac, go)}
    ${_ftrFull(W, H, go)}
  `);
}

function _thumbTopBand(W, H, ac, go) {
  const bandH = 24;
  return _svg(W, H, `
    <rect x="0" y="0" width="${W}" height="${H}" fill="#fff"/>
    <!-- Band atas -->
    <rect x="0" y="0" width="${W}" height="${bandH}" fill="${ac}"/>
    <!-- Garis gold -->
    <rect x="0" y="${bandH}" width="${W}" height="2.5" fill="${go}"/>
    <!-- Logo di band -->
    <rect x="10" y="8" width="18" height="5" fill="rgba(255,255,255,.7)" rx="1"/>
    <!-- Konten tengah -->
    <rect x="16" y="${bandH + 16}" width="${W - 36}" height="1.5" fill="${ac}" rx="1"/>
    <rect x="16" y="${bandH + 22}" width="${W - 28}" height="8" fill="#222" rx="1"/>
    <rect x="16" y="${bandH + 33}" width="${W - 40}" height="5" fill="#555" rx="1"/>
    <rect x="16" y="${bandH + 42}" width="20" height="2" fill="${go}"/>
    ${_hdrStrip(W, H, ac, go)}
    ${_ftrBar(W, H, ac, go)}
  `);
}

function _thumbBottomBand(W, H, ac, go) {
  const bandH = 20;
  return _svg(W, H, `
    <rect x="0" y="0" width="${W}" height="${H}" fill="#fff"/>
    <!-- Logo -->
    <rect x="12" y="18" width="18" height="5" fill="#ccc" rx="1"/>
    <!-- Konten -->
    <rect x="12" y="34" width="${W - 28}" height="8" fill="#222" rx="1"/>
    <rect x="12" y="45" width="${W - 40}" height="5" fill="#555" rx="1"/>
    <rect x="12" y="54" width="20" height="1" fill="#ddd"/>
    <rect x="12" y="60" width="${W - 48}" height="2" fill="#aaa" rx="1"/>
    <!-- Garis gold -->
    <rect x="0" y="${H - bandH - 2}" width="${W}" height="2" fill="linear-gradient(90deg,${go},${ac})"/>
    <rect x="0" y="${H - bandH - 2}" width="${W}" height="2" fill="${go}"/>
    <!-- Band bawah -->
    <rect x="0" y="${H - bandH}" width="${W}" height="${bandH}" fill="${ac}"/>
    <rect x="12" y="${H - bandH + 7}" width="24" height="3" fill="rgba(255,255,255,.5)" rx="1"/>
    ${_hdrStrip(W, H, ac, go)}
    ${_ftrMinimal(W, H)}
  `);
}

function _thumbDiagonal(W, H, ac, go) {
  const cut = Math.round(W * 0.55);
  return _svg(W, H, `
    <rect x="0" y="0" width="${W}" height="${H}" fill="#fff"/>
    <!-- Panel diagonal -->
    <polygon points="0,0 ${cut},0 ${cut - 14},${H} 0,${H}" fill="${ac}"/>
    <!-- Garis gold diagonal -->
    <polygon points="${cut},0 ${cut + 4},0 ${cut - 10},${H} ${cut - 14},${H}" fill="${go}"/>
    <!-- Logo panel kiri -->
    <rect x="10" y="18" width="16" height="4" fill="rgba(255,255,255,.6)" rx="1"/>
    <!-- Konten kanan -->
    <rect x="${cut - 8}" y="28" width="${W - cut + 2}" height="1.5" fill="${ac}" rx="1"/>
    <rect x="${cut - 8}" y="34" width="${W - cut - 2}" height="7" fill="#222" rx="1"/>
    <rect x="${cut - 8}" y="44" width="${W - cut + 2}" height="5" fill="#555" rx="1"/>
    ${_hdrStrip(W, H, ac, go)}
    ${_ftrBar(W, H, ac, go)}
  `);
}

function _thumbSplitRight(W, H, ac, go) {
  const panelW = Math.round(W * 0.33);
  const contentW = W - panelW;
  return _svg(W, H, `
    <rect x="0" y="0" width="${W}" height="${H}" fill="#fff"/>
    <!-- Panel kanan -->
    <rect x="${contentW}" y="0" width="${panelW}" height="${H}" fill="${ac}"/>
    <!-- Garis vertikal di dalam panel -->
    <rect x="${contentW + panelW / 2}" y="${H / 3}" width="1" height="${H / 3}" fill="rgba(255,255,255,.2)"/>
    <!-- Konten kiri -->
    <rect x="12" y="20" width="18" height="5" fill="#ccc" rx="1"/>
    <rect x="12" y="34" width="${contentW - 24}" height="8" fill="#222" rx="1"/>
    <rect x="12" y="45" width="${contentW - 32}" height="5" fill="#555" rx="1"/>
    <rect x="12" y="54" width="20" height="1.5" fill="${go}"/>
    <rect x="12" y="60" width="${contentW - 40}" height="2" fill="#aaa" rx="1"/>
    ${_hdrStrip(W, H, ac, go)}
    ${_ftrBar(W, H, ac, go)}
  `);
}

// ── Shared mini-elements ──────────────────────────────────────────────────────

function _hdrStrip(W, H, ac, go) {
  return `
    <rect x="0" y="0" width="${W}" height="8" fill="${ac}" opacity=".85"/>
    <rect x="0" y="8" width="${W}" height="1.5" fill="${go}"/>
  `;
}

function _ftrBar(W, H, ac, go) {
  return `
    <rect x="0" y="${H - 8}" width="${W}" height="1.5" fill="${go}"/>
    <rect x="0" y="${H - 6.5}" width="${W}" height="6.5" fill="#f5f5f5"/>
  `;
}

function _ftrFull(W, H, go) {
  return `<rect x="0" y="${H - 8}" width="${W}" height="8" fill="${go}"/>`;
}

function _ftrMinimal(W, H) {
  return `<rect x="0" y="${H - 5}" width="${W}" height="1" fill="#eee"/>`;
}

function _svg(W, H, content) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${content}</svg>`;
}
