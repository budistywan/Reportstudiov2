/**
 * ui/presets/coverRenderer.js — Render halaman sampul dari preset
 *
 * Entry point:
 *   renderCover(cfg) → HTMLElement (.a4.cover-pg)
 *
 * cfg yang dipakai:
 *   cfg.preset    → id preset
 *   cfg.title     → judul laporan
 *   cfg.company   → nama perusahaan
 *   cfg.year      → tahun
 *   cfg.accent    → warna accent
 *   cfg.gold      → warna gold
 *   cfg.logo      → base64 string (null jika belum upload)
 *
 * Layout yang diimplementasikan:
 *   'centered'    → logo + judul di tengah
 *   'split-left'  → panel warna kiri, konten kanan
 *   'split-right' → konten kiri, panel warna kanan
 *   'full-color'  → background penuh
 *   'top-band'    → band atas
 *   'bottom-band' → band bawah
 *   'diagonal'    → clip-path diagonal
 *
 * CSS: styles/presets.css (.cover-*)
 */

import { getPreset } from '../../core/presets.js';

/**
 * @param {Object} cfg - dari store.getCfg()
 * @returns {HTMLElement}
 */
export function renderCover(cfg) {
  const preset = getPreset(cfg.preset);
  const def    = preset.cover;

  const wrap = document.createElement('div');
  wrap.className = 'a4 cover-pg';
  wrap.dataset.coverLayout = def.layout;

  switch (def.layout) {
    case 'split-left':   wrap.appendChild(_splitLeft(cfg, def));   break;
    case 'split-right':  wrap.appendChild(_splitRight(cfg, def));  break;
    case 'full-color':   wrap.appendChild(_fullColor(cfg, def));   break;
    case 'top-band':     wrap.appendChild(_topBand(cfg, def));     break;
    case 'bottom-band':  wrap.appendChild(_bottomBand(cfg, def));  break;
    case 'diagonal':     wrap.appendChild(_diagonal(cfg, def));    break;
    case 'centered':
    default:             wrap.appendChild(_centered(cfg, def));    break;
  }

  return wrap;
}

// ── Layout renderers ──────────────────────────────────────────────────────────

function _centered(cfg, def) {
  const el = document.createElement('div');
  el.className = 'cover-centered';
  el.style.cssText = `
    height: 100%; display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    padding: 60px 80px; text-align: center;
    background: #fff;
  `;
  el.innerHTML = `
    ${_logoHTML(cfg, def, 'center', 'margin-bottom:32px')}
    <div class="cover-divider-top" style="width:60px;height:3px;background:${cfg.accent};margin-bottom:28px"></div>
    <div class="cover-title" style="font-family:var(--doc-h);font-size:2rem;font-weight:900;color:#1a1a2a;line-height:1.15;margin-bottom:16px">${cfg.title}</div>
    ${def.showDivider ? `<div style="width:40px;height:1px;background:${cfg.gold};margin:16px auto"></div>` : ''}
    <div class="cover-company" style="font-size:.85rem;color:#555;font-family:var(--doc-m);font-weight:500;margin-bottom:8px">${cfg.company}</div>
    ${def.showYear ? `<div class="cover-year" style="font-size:.7rem;color:#999;font-family:'JetBrains Mono',monospace">${cfg.year}</div>` : ''}
  `;
  return el;
}

function _splitLeft(cfg, def) {
  const el = document.createElement('div');
  el.className = 'cover-split-left';
  el.style.cssText = 'height:100%;display:flex;';
  el.innerHTML = `
    <!-- Panel kiri -->
    <div style="width:38%;background:${cfg.accent};display:flex;flex-direction:column;justify-content:space-between;padding:40px 28px;position:relative;overflow:hidden;">
      <div style="position:absolute;top:-40px;right:-40px;width:160px;height:160px;background:rgba(255,255,255,.06);border-radius:50%"></div>
      <div style="position:absolute;bottom:60px;left:-30px;width:100px;height:100px;background:rgba(255,255,255,.04);border-radius:50%"></div>
      ${_logoHTML(cfg, def, 'left', 'position:relative;z-index:1')}
      <div style="position:relative;z-index:1">
        <div style="width:32px;height:2px;background:${cfg.gold};margin-bottom:14px"></div>
        <div style="font-size:.62rem;color:rgba(255,255,255,.6);font-family:'JetBrains Mono',monospace;letter-spacing:.12em;text-transform:uppercase">${cfg.company}</div>
        ${def.showYear ? `<div style="font-size:.58rem;color:rgba(255,255,255,.4);font-family:'JetBrains Mono',monospace;margin-top:4px">${cfg.year}</div>` : ''}
      </div>
    </div>
    <!-- Konten kanan -->
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center;padding:60px 48px;">
      <div style="width:48px;height:3px;background:${cfg.gold};margin-bottom:28px"></div>
      <div style="font-family:var(--doc-h);font-size:2.1rem;font-weight:900;color:#1a1a2a;line-height:1.15;margin-bottom:20px">${cfg.title}</div>
      ${def.showDivider ? `<div style="width:100%;height:1px;background:#eee;margin-bottom:20px"></div>` : ''}
      <div style="font-size:.78rem;color:#777;font-family:var(--doc-m)">${cfg.company}</div>
    </div>
  `;
  return el;
}

function _splitRight(cfg, def) {
  const el = document.createElement('div');
  el.className = 'cover-split-right';
  el.style.cssText = 'height:100%;display:flex;';
  el.innerHTML = `
    <!-- Konten kiri -->
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center;padding:60px 48px;">
      ${_logoHTML(cfg, def, 'left', 'margin-bottom:32px')}
      <div style="font-family:var(--doc-h);font-size:2rem;font-weight:900;color:#1a1a2a;line-height:1.15;margin-bottom:20px">${cfg.title}</div>
      ${def.showDivider ? `<div style="width:48px;height:2px;background:${cfg.gold};margin-bottom:16px"></div>` : ''}
      <div style="font-size:.78rem;color:#777;font-family:var(--doc-m)">${cfg.company}</div>
      ${def.showYear ? `<div style="font-size:.65rem;color:#bbb;font-family:'JetBrains Mono',monospace;margin-top:6px">${cfg.year}</div>` : ''}
    </div>
    <!-- Panel kanan -->
    <div style="width:35%;background:${cfg.accent};display:flex;flex-direction:column;justify-content:center;align-items:center;padding:40px 24px;position:relative;overflow:hidden;">
      <div style="position:absolute;bottom:-50px;left:-50px;width:200px;height:200px;background:rgba(255,255,255,.05);border-radius:50%"></div>
      <div style="width:2px;height:80px;background:rgba(255,255,255,.3);margin-bottom:20px"></div>
      <div style="font-family:'JetBrains Mono',monospace;font-size:.58rem;color:rgba(255,255,255,.5);letter-spacing:.16em;text-transform:uppercase;writing-mode:vertical-rl;text-orientation:mixed">${cfg.company}</div>
    </div>
  `;
  return el;
}

function _fullColor(cfg, def) {
  const el = document.createElement('div');
  el.className = 'cover-full-color';
  el.style.cssText = `height:100%;background:${cfg.accent};display:flex;flex-direction:column;justify-content:flex-end;padding:60px 64px;position:relative;overflow:hidden;`;
  el.innerHTML = `
    <!-- Dekorasi -->
    <div style="position:absolute;top:-60px;right:-60px;width:280px;height:280px;background:rgba(255,255,255,.05);border-radius:50%"></div>
    <div style="position:absolute;top:40px;right:80px;width:120px;height:120px;background:rgba(255,255,255,.04);border-radius:50%"></div>
    <!-- Logo pojok kiri atas -->
    <div style="position:absolute;top:44px;left:64px;">
      ${_logoHTML(cfg, def, 'left', '')}
    </div>
    <!-- Konten bawah -->
    <div style="position:relative;z-index:2">
      <div style="width:48px;height:3px;background:${cfg.gold};margin-bottom:20px"></div>
      <div style="font-family:var(--doc-h);font-size:2.4rem;font-weight:900;color:#fff;line-height:1.1;margin-bottom:20px">${cfg.title}</div>
      <div style="height:1px;background:rgba(255,255,255,.2);margin-bottom:16px"></div>
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <div style="font-size:.78rem;color:rgba(255,255,255,.8);font-family:var(--doc-m)">${cfg.company}</div>
        ${def.showYear ? `<div style="font-size:.65rem;color:rgba(255,255,255,.5);font-family:'JetBrains Mono',monospace">${cfg.year}</div>` : ''}
      </div>
    </div>
  `;
  return el;
}

function _topBand(cfg, def) {
  const el = document.createElement('div');
  el.className = 'cover-top-band';
  el.style.cssText = 'height:100%;display:flex;flex-direction:column;background:#fff;';
  el.innerHTML = `
    <!-- Band atas -->
    <div style="background:${cfg.accent};padding:36px 60px;display:flex;align-items:center;justify-content:space-between;">
      ${_logoHTML(cfg, def, 'left', '')}
      ${def.showYear ? `<div style="font-family:'JetBrains Mono',monospace;font-size:.65rem;color:rgba(255,255,255,.6)">${cfg.year}</div>` : ''}
    </div>
    <!-- Garis emas -->
    <div style="height:4px;background:${cfg.gold}"></div>
    <!-- Konten -->
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center;padding:60px;">
      <div style="font-size:.65rem;color:${cfg.accent};font-family:'JetBrains Mono',monospace;letter-spacing:.12em;text-transform:uppercase;margin-bottom:20px">${cfg.company}</div>
      <div style="font-family:var(--doc-h);font-size:2.2rem;font-weight:900;color:#1a1a2a;line-height:1.15;margin-bottom:24px">${cfg.title}</div>
      ${def.showDivider ? `<div style="width:60px;height:2px;background:${cfg.gold}"></div>` : ''}
    </div>
  `;
  return el;
}

function _bottomBand(cfg, def) {
  const el = document.createElement('div');
  el.className = 'cover-bottom-band';
  el.style.cssText = 'height:100%;display:flex;flex-direction:column;background:#fff;';
  el.innerHTML = `
    <!-- Konten atas -->
    <div style="flex:1;display:flex;flex-direction:column;justify-content:center;padding:60px;">
      ${_logoHTML(cfg, def, def.logoPosition === 'top-left' ? 'left' : 'right', 'margin-bottom:40px')}
      <div style="font-family:var(--doc-h);font-size:2.2rem;font-weight:700;color:#1a1a2a;line-height:1.2;margin-bottom:16px">${cfg.title}</div>
      ${def.showDivider ? `<div style="width:48px;height:1px;background:#ddd;margin-bottom:16px"></div>` : ''}
      <div style="font-size:.75rem;color:#888;font-family:var(--doc-m)">${cfg.company}</div>
    </div>
    <!-- Garis emas -->
    <div style="height:3px;background:linear-gradient(90deg,${cfg.gold},${cfg.accent})"></div>
    <!-- Band bawah -->
    <div style="background:${cfg.accent};padding:24px 60px;display:flex;align-items:center;justify-content:space-between;">
      <div style="font-size:.62rem;color:rgba(255,255,255,.7);font-family:'JetBrains Mono',monospace;letter-spacing:.08em">${cfg.company.toUpperCase()}</div>
      ${def.showYear ? `<div style="font-size:.62rem;color:rgba(255,255,255,.5);font-family:'JetBrains Mono',monospace">${cfg.year}</div>` : ''}
    </div>
  `;
  return el;
}

function _diagonal(cfg, def) {
  const el = document.createElement('div');
  el.className = 'cover-diagonal';
  el.style.cssText = 'height:100%;position:relative;background:#fff;overflow:hidden;';
  el.innerHTML = `
    <!-- Background diagonal via clip-path -->
    <div style="
      position:absolute;inset:0;
      background:${cfg.accent};
      clip-path:polygon(0 0, 58% 0, 42% 100%, 0 100%);
    "></div>
    <!-- Dekorasi lingkaran -->
    <div style="position:absolute;top:60px;left:30%;width:200px;height:200px;border:1px solid rgba(255,255,255,.08);border-radius:50%;transform:translateX(-50%)"></div>
    <!-- Garis emas diagonal -->
    <div style="
      position:absolute;inset:0;
      background:${cfg.gold};
      clip-path:polygon(56% 0, 60% 0, 44% 100%, 40% 100%);
      opacity:.8;
    "></div>
    <!-- Logo kiri atas (panel warna) -->
    <div style="position:absolute;top:48px;left:40px;">
      ${_logoHTML(cfg, def, 'left', 'filter:brightness(0) invert(1)')}
    </div>
    <!-- Konten kanan -->
    <div style="position:absolute;right:0;top:0;bottom:0;width:50%;display:flex;flex-direction:column;justify-content:center;padding:60px 48px 60px 24px;">
      <div style="font-size:.62rem;color:${cfg.accent};font-family:'JetBrains Mono',monospace;letter-spacing:.12em;text-transform:uppercase;margin-bottom:16px">${cfg.company}</div>
      <div style="font-family:var(--doc-h);font-size:1.9rem;font-weight:900;color:#1a1a2a;line-height:1.15;margin-bottom:20px">${cfg.title}</div>
      ${def.showYear ? `<div style="font-size:.65rem;color:#aaa;font-family:'JetBrains Mono',monospace">${cfg.year}</div>` : ''}
    </div>
  `;
  return el;
}

// ── Helper: logo / logotext ───────────────────────────────────────────────────
function _logoHTML(cfg, def, align = 'left', extraStyle = '') {
  if (!def.showLogo) return '';
  if (cfg.logo) {
    return `<img src="${cfg.logo}" style="height:36px;object-fit:contain;display:block;${align === 'center' ? 'margin:0 auto;' : ''}${extraStyle}" alt="${cfg.company}"/>`;
  }
  // Fallback: teks
  return `<div style="font-family:'JetBrains Mono',monospace;font-size:.72rem;font-weight:700;color:inherit;${extraStyle}">${cfg.company || 'LOGO'}</div>`;
}
