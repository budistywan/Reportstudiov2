/**
 * ui/presets/headerRenderer.js — Render header halaman konten
 *
 * Entry point:
 *   renderHeader(cfg, context) → HTMLElement (.a4-hdr)
 *
 * context:
 *   context.babTitle   → judul bab aktif (string)
 *   context.pageNum    → nomor halaman (number)
 *
 * Layout:
 *   'strip'   → background solid accent
 *   'logobar' → border bottom accent, background putih
 *   'corner'  → block warna kiri sebagai logo holder
 *   'minimal' → teks tipis + garis gradient
 *   'none'    → return null (tidak ada header)
 *
 * CSS: styles/presets.css (.hdr-*)
 */

import { getPreset } from '../../core/presets.js';

/**
 * @param {Object} cfg       - dari store.getCfg()
 * @param {Object} context   - { babTitle, pageNum }
 * @returns {HTMLElement|null}
 */
export function renderHeader(cfg, context = {}) {
  const preset = getPreset(cfg.preset);
  const def    = preset.header;

  if (def.layout === 'none') return null;

  const el = document.createElement('div');
  el.className = `a4-hdr hdr-${def.layout}`;

  switch (def.layout) {
    case 'strip':   _strip(el, cfg, def, context);   break;
    case 'logobar': _logobar(el, cfg, def, context); break;
    case 'corner':  _corner(el, cfg, def, context);  break;
    case 'minimal': _minimal(el, cfg, def, context); break;
  }

  return el;
}

// ── Layout renderers ──────────────────────────────────────────────────────────

function _strip(el, cfg, def, ctx) {
  el.innerHTML = `
    <div class="hdr-inner" style="display:flex;align-items:center;justify-content:space-between;padding:10px 48px;background:${cfg.accent};">
      ${_logoBlock(cfg, def, 'white')}
      <div class="hdr-right" style="text-align:right;">
        ${def.showTitle    ? `<div style="font-size:.66rem;color:rgba(255,255,255,.88);font-family:var(--doc-m);font-weight:500">${cfg.title}</div>` : ''}
        ${def.showCompany  ? `<div style="font-size:.54rem;color:rgba(255,255,255,.58);font-family:'JetBrains Mono',monospace">${cfg.company}</div>` : ''}
      </div>
    </div>
    <div style="height:3px;background:${cfg.gold}"></div>
  `;
}

function _logobar(el, cfg, def, ctx) {
  el.innerHTML = `
    <div class="hdr-inner" style="display:flex;align-items:center;justify-content:space-between;padding:10px 48px 8px;background:#fff;">
      ${_logoBlock(cfg, def, cfg.accent)}
      <div class="hdr-right" style="text-align:right;">
        ${def.showTitle    ? `<div style="font-size:.66rem;color:#2c2c3c;font-family:var(--doc-m);font-weight:600">${cfg.title}</div>` : ''}
        ${def.showCompany  ? `<div style="font-size:.54rem;color:#888;font-family:'JetBrains Mono',monospace">${cfg.company}</div>` : ''}
      </div>
    </div>
    <div style="height:2.5px;background:linear-gradient(90deg,${cfg.accent} 0%,${cfg.accent} 75%,${cfg.gold} 100%)"></div>
  `;
}

function _corner(el, cfg, def, ctx) {
  el.innerHTML = `
    <div class="hdr-inner" style="display:flex;align-items:stretch;min-height:42px;">
      <!-- Block warna kiri -->
      <div style="width:50px;background:${cfg.accent};display:flex;align-items:center;justify-content:center;flex-shrink:0;">
        ${def.showLogo && cfg.logo
          ? `<img src="${cfg.logo}" style="height:22px;filter:brightness(0) invert(1);padding:2px" alt=""/>`
          : `<span style="font-family:'JetBrains Mono',monospace;font-size:.5rem;font-weight:700;color:#fff">${(cfg.company||'').slice(0,4).toUpperCase()}</span>`
        }
      </div>
      <!-- Teks info -->
      <div style="flex:1;display:flex;align-items:center;justify-content:space-between;padding:0 48px 0 14px;border-bottom:1px solid #eee;background:#fff;">
        ${def.showTitle   ? `<div style="font-size:.66rem;color:#2c2c3c;font-weight:600;font-family:var(--doc-m)">${cfg.title}</div>` : ''}
        ${def.showCompany ? `<div style="font-size:.54rem;color:#888;font-family:'JetBrains Mono',monospace">${cfg.company}</div>` : ''}
      </div>
    </div>
  `;
}

function _minimal(el, cfg, def, ctx) {
  el.innerHTML = `
    <div class="hdr-inner" style="display:flex;align-items:center;justify-content:space-between;padding:8px 48px;background:#fff;">
      ${def.showLogo && cfg.logo
        ? `<img src="${cfg.logo}" style="height:20px;object-fit:contain;opacity:.7" alt=""/>`
        : `<span style="font-family:'JetBrains Mono',monospace;font-size:.6rem;font-weight:700;color:#aaa">${cfg.company || ''}</span>`
      }
      ${def.showTitle ? `<div style="font-size:.62rem;color:#888;font-family:var(--doc-m)">${cfg.title}</div>` : ''}
    </div>
    <div style="height:1px;background:linear-gradient(90deg,${cfg.accent},transparent)"></div>
  `;
}

// ── Helper ────────────────────────────────────────────────────────────────────
function _logoBlock(cfg, def, fallbackColor) {
  if (!def.showLogo) return '';
  if (cfg.logo) {
    const isOnColor = fallbackColor === 'white';
    return `<img src="${cfg.logo}" style="height:26px;object-fit:contain;${isOnColor ? 'filter:brightness(0) invert(1);' : ''}" alt="${cfg.company}"/>`;
  }
  const isWhite = fallbackColor === 'white';
  return `<span style="font-family:'JetBrains Mono',monospace;font-size:.65rem;font-weight:700;color:${isWhite ? '#fff' : cfg.accent}">${cfg.company || 'LOGO'}</span>`;
}
