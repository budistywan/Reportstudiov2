/**
 * ui/presets/presetPicker.js — UI gallery untuk memilih preset
 *
 * Dua mode render:
 *
 *   renderPickerWelcome(container, onChange)
 *     → Dipakai di welcome screen tab "🎨 Preset"
 *     → Grid 3 kolom, thumbnail besar + nama + deskripsi + badge kategori
 *     → onChange(presetId) dipanggil saat pilih
 *
 *   renderPickerPanel(container, onChange)
 *     → Dipakai di right panel accordion "🎨 Preset Desain"
 *     → Grid 2 kolom, thumbnail lebih kecil + nama saja
 *     → onChange(presetId) dipanggil saat pilih
 *
 * Keduanya:
 *   - Highlight preset aktif (dari store.getCfg().preset)
 *   - Warna thumbnail mengikuti cfg.accent & cfg.gold live
 *   - Klik preset → store.setCfg({ preset: id, accent: defaultAccent, gold: defaultGold })
 *     kecuali user sudah custom warna → hanya update preset, warna dipertahankan
 *
 * CSS: styles/presets.css (.preset-picker-*, .preset-card-*)
 */

import { PRESETS, getPreset } from '../../core/presets.js';
import { store }              from '../../core/store.js';
import { presetThumbnail }    from './thumbnails.js';

// ── Welcome screen picker ─────────────────────────────────────────────────────

/**
 * @param {HTMLElement} container
 * @param {Function} onChange - callback(presetId)
 */
export function renderPickerWelcome(container, onChange) {
  const cfg = store.getCfg();
  container.innerHTML = '';
  container.className = 'preset-picker-welcome';

  PRESETS.forEach(preset => {
    const card = _makeCard(preset, cfg, 'welcome');
    card.addEventListener('click', () => {
      _selectPreset(preset, false);  // welcome: update accent+gold juga
      _highlightCard(container, preset.id);
      onChange?.(preset.id);
    });
    container.appendChild(card);
  });
}

// ── Panel picker ──────────────────────────────────────────────────────────────

/**
 * @param {HTMLElement} container
 * @param {Function} onChange - callback(presetId)
 */
export function renderPickerPanel(container, onChange) {
  const cfg = store.getCfg();
  container.innerHTML = '';
  container.className = 'preset-picker-panel';

  PRESETS.forEach(preset => {
    const card = _makeCard(preset, cfg, 'panel');
    card.addEventListener('click', () => {
      _selectPreset(preset, true);  // panel: pertahankan warna custom
      _highlightCard(container, preset.id);
      onChange?.(preset.id);
    });
    container.appendChild(card);
  });
}

// ── Shared card builder ───────────────────────────────────────────────────────

function _makeCard(preset, cfg, mode) {
  const isActive  = cfg.preset === preset.id;
  const accent    = cfg.accent || preset.defaultAccent;
  const gold      = cfg.gold   || preset.defaultGold;
  const isWelcome = mode === 'welcome';

  const card = document.createElement('div');
  card.className = `preset-card preset-card-${mode}${isActive ? ' active' : ''}`;
  card.dataset.presetId = preset.id;

  const thumb = presetThumbnail(preset, accent, gold);

  card.innerHTML = `
    <div class="preset-thumb">${thumb}</div>
    <div class="preset-info">
      <div class="preset-name">${preset.name}</div>
      ${isWelcome ? `
        <div class="preset-desc">${preset.description}</div>
        <div class="preset-badge preset-badge-${preset.category}">${_categoryLabel(preset.category)}</div>
      ` : ''}
    </div>
    ${isActive ? '<div class="preset-check">✓</div>' : ''}
  `;

  return card;
}

// ── State mutation ────────────────────────────────────────────────────────────

/**
 * @param {Preset} preset
 * @param {boolean} keepColors - true = pertahankan accent/gold user, false = pakai default preset
 */
function _selectPreset(preset, keepColors) {
  const update = { preset: preset.id };
  if (!keepColors) {
    update.accent = preset.defaultAccent;
    update.gold   = preset.defaultGold;
  }
  store.setCfg(update);
}

function _highlightCard(container, activeId) {
  container.querySelectorAll('.preset-card').forEach(c => {
    const isActive = c.dataset.presetId === activeId;
    c.classList.toggle('active', isActive);
    // Update/remove checkmark
    let check = c.querySelector('.preset-check');
    if (isActive && !check) {
      check = document.createElement('div');
      check.className = 'preset-check';
      check.textContent = '✓';
      c.appendChild(check);
    } else if (!isActive && check) {
      check.remove();
    }
  });
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function _categoryLabel(cat) {
  return { formal: 'Formal', modern: 'Modern', minimal: 'Minimalis', bold: 'Bold' }[cat] || cat;
}

/** Refresh thumbnails saat accent/gold berubah (dipanggil dari store listener) */
export function refreshThumbnails(container) {
  if (!container) return;
  const cfg = store.getCfg();
  container.querySelectorAll('.preset-card').forEach(card => {
    const preset = getPreset(card.dataset.presetId);
    const thumb  = card.querySelector('.preset-thumb');
    if (thumb) thumb.innerHTML = presetThumbnail(preset, cfg.accent, cfg.gold);
  });
}
