/**
 * ui/topbar.js — Top toolbar
 *
 * Tanggung jawab:
 *  - Render topbar ke #tb
 *  - Tombol: toggle sidebar, toggle panel, Save, Export JSON, Import JSON
 *  - Breadcrumb / title sub-bab aktif
 *  - Tombol Export (buka exportModal) — PDF, DOCX, ICML
 *
 * CSS: styles/shell.css (topbar section)
 */

import { store } from '../core/store.js';
import { toggleSidebar } from './sidebar.js';

export function initTopbar() {
  _render();
  _bindEvents();

  store.on('project:ready', _show);
  store.on('nav:change', _updateTitle);
}

function _render() {
  // TODO: inject topbar HTML ke #tb
}

function _bindEvents() {
  // TODO: bind btn-sb, btn-rp, save, export, import
}

function _updateTitle(subId) {
  // TODO: update #tb-title dengan nama sub-bab aktif
}

function _show() {
  document.getElementById('tb').style.display = 'flex';
}

function doSave() {
  store.load(); // refresh
  // TODO: showToast('✓ Tersimpan')
}

function doExportJSON() {
  const json = store.exportJSON();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
  a.download = `report-studio-${Date.now()}.json`;
  a.click();
}

function doImportJSON(file) {
  const r = new FileReader();
  r.onload = e => {
    try {
      store.importJSON(e.target.result);
    } catch(err) {
      // TODO: showToast('⚠ File tidak valid')
    }
  };
  r.readAsText(file);
}
