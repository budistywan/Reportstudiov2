/**
 * ui/sidebar.js — Sidebar navigasi (tree bab/sub-bab)
 *
 * Tanggung jawab:
 *  - Render nav tree ke #sb dari skeleton
 *  - Progress bar (sub-bab terisi / total)
 *  - Highlight sub-bab aktif
 *  - Toggle sidebar (mobile & desktop)
 *  - Danger zone: reset sub-bab, new project
 *
 * Mendengarkan:
 *  store.on('skeleton:change') → rebuild tree
 *  store.on('pages:change')    → update progress & dot indicator
 *  store.on('nav:change')      → update active row
 *  store.on('project:ready')   → show sidebar
 *
 * CSS: styles/shell.css (sidebar section)
 */

import { store } from '../core/store.js';

export function initSidebar() {
  _render();
  _bindEvents();

  store.on('project:ready', _show);
  store.on('skeleton:change', _buildTree);
  store.on('pages:change', _updateProgress);
  store.on('nav:change', _updateActive);
}

function _render() {
  // TODO: inject sidebar HTML ke #sb
}

function _buildTree() {
  // TODO: generate .sb-row items dari skeleton
}

function _updateProgress() {
  // TODO: hitung filled/total, update progress bar
}

function _updateActive(subId) {
  // TODO: toggle .act class pada row yang sesuai
}

function _show() {
  document.getElementById('sb').style.display = 'flex';
}

function toggleSidebar() {
  // TODO: toggle .off class, adjust main margin
}

export { toggleSidebar };
