/**
 * ui/welcome.js — Welcome screen & skeleton builder
 *
 * Tanggung jawab:
 *  - Render welcome screen ke #welcome-screen
 *  - Form: judul, perusahaan, tahun
 *  - Skeleton builder: tab "Paste Teks" + tab "Builder Manual"
 *  - Parser teks → skeleton[]
 *  - Validasi form → enable tombol "Mulai"
 *  - Import JSON project lama
 *  - Emit: store.setSkeleton(), store.setCfg(), store.setProjectReady()
 *
 * CSS: styles/welcome.css
 */

import { store } from '../core/store.js';
import { FM_KEYWORDS, ROMAN } from '../core/config.js';

export function initWelcome() {
  _render();
  _bindEvents();

  // Jika sudah ada project, langsung hide
  store.on('project:ready', () => {
    document.getElementById('welcome-screen').style.display = 'none';
  });
}

// ── Render ────────────────────────────────────────────────────────────────────
function _render() {
  // TODO: pindahkan HTML welcome screen dari v4 ke sini
  // Gunakan template literal → innerHTML ke #welcome-screen
}

// ── Events ────────────────────────────────────────────────────────────────────
function _bindEvents() {
  // TODO: oninput validate, tab switch, paste parse, start project
}

// ── Parser ────────────────────────────────────────────────────────────────────
/**
 * Parse raw text (daftar isi) → skeleton[]
 * Dipindahkan dari skelParsePaste() v4
 */
export function parseSkeletonText(raw) {
  // TODO: migrate logic dari v4 skelParsePaste()
  return [];
}

// ── Validate ─────────────────────────────────────────────────────────────────
function _validate() {
  // TODO: cek title & company terisi + minimal 1 bab
}
