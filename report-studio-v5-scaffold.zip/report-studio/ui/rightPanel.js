/**
 * ui/rightPanel.js — Right panel editor
 *
 * Tanggung jawab:
 *  - Render panel ke #rp
 *  - Accordion sections:
 *      📝 Tata Letak Teks  → addTextBlock()
 *      🎨 Elemen Visual    → addBlock() (image, collage, stat, quote, diagram)
 *      📑 Halaman          → list halaman + tambah
 *      🎯 Opener Bab       → warna opener
 *      🔤 Tipografi        → font pairing
 *      🏷 Gaya Header      → hdrStyle + logo upload
 *      ⚙️ Brand & Info     → edit nama, tahun
 *      ✨ Fill Konten      → shortcut ke fill/fillPanel.js
 *      📤 Export           → shortcut ke export/exportModal.js
 *
 * CSS: styles/panel.css
 */

import { store } from '../core/store.js';

export function initPanel() {
  _render();
  _bindEvents();

  store.on('project:ready', _show);
  store.on('nav:change', _refresh);
}

function _render() {
  // TODO: inject full panel HTML ke #rp
}

function _bindEvents() {
  // TODO: accordion toggles, color pickers, typo cards, header style cards
}

function _refresh(subId) {
  // TODO: update panel state berdasarkan sub-bab aktif
}

function _show() {
  document.getElementById('rp').style.display = 'flex';
}

function togglePanel() {
  // TODO: toggle .off class, adjust main margin
}

export { togglePanel };
