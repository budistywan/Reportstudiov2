/**
 * ui/toast.js — Toast notification
 *
 * Usage:
 *   import { showToast } from '../ui/toast.js';
 *   showToast('✓ Tersimpan');
 *   showToast('⚠ Gagal', 'error');
 */

let _timer = null;

export function showToast(msg, type = 'info') {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.className = `toast show ${type}`;
  clearTimeout(_timer);
  _timer = setTimeout(() => {
    el.classList.remove('show');
  }, 2400);
}

/**
 * Confirm modal dengan keyword typing
 * @param {Object} opts
 * @param {string} opts.icon
 * @param {string} opts.title
 * @param {string} opts.desc  (bisa mengandung HTML)
 * @param {string} opts.keyword  — user harus ketik ini
 * @param {string} opts.btnLabel
 * @param {Function} opts.onConfirm
 */
export function showConfirm({ icon, title, desc, keyword, btnLabel, onConfirm }) {
  const ov = document.createElement('div');
  ov.className = 'modal-overlay';
  ov.innerHTML = `
    <div class="modal-box">
      <div class="modal-icon">${icon}</div>
      <div class="modal-title">${title}</div>
      <div class="modal-desc">${desc}</div>
      <div class="modal-hint">Ketik <strong class="modal-keyword">${keyword}</strong> untuk konfirmasi</div>
      <input class="modal-confirm-input" placeholder="${keyword}" id="modal-inp"/>
      <div class="modal-actions">
        <button class="modal-btn modal-btn-cancel">Batal</button>
        <button class="modal-btn modal-btn-danger" id="modal-confirm-btn">${btnLabel}</button>
      </div>
    </div>`;

  document.body.appendChild(ov);

  const inp = ov.querySelector('#modal-inp');
  const btn = ov.querySelector('#modal-confirm-btn');

  inp.addEventListener('input', () => {
    const match = inp.value === keyword;
    inp.classList.toggle('valid', match);
    btn.classList.toggle('enabled', match);
  });

  btn.addEventListener('click', () => {
    if (inp.value !== keyword) return;
    ov.remove();
    onConfirm();
  });

  ov.querySelector('.modal-btn-cancel').addEventListener('click', () => ov.remove());
  ov.addEventListener('mousedown', e => { if (e.target === ov) ov.remove(); });
}
